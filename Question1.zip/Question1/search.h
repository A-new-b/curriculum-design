#pragma once
#include "big_category.h"

LinkList search_Item( big_category category , const char name[]);

big_category search_Big_Category(big_category category, char name[]);

int search_Items_Sold_Out(big_category category);

