#pragma once
#include "linklist.h"
#include "big_category.h"
#include "search.h"

enum  unit {weight , for_count};

big_category init_Supermarket();

big_category close_down(big_category catalog);
